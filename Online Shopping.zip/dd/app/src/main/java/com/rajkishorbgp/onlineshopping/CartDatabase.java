package com.rajkishorbgp.onlineshopping;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import androidx.annotation.Nullable;

import java.util.ArrayList;

public class CartDatabase extends SQLiteOpenHelper {
    private static final String DB_NAME    = "cartDatabase";
    private static final int    DB_VERSION = 1;
    private static final String TABLE_NAME = "cartDatabase";

    private final Context context;

    public CartDatabase(@Nullable Context context) {
        super(context, DB_NAME, null, DB_VERSION);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_TABLE_QUERY = "CREATE TABLE " + TABLE_NAME + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "itemName TEXT, " +
                "itemDisc TEXT, " +
                "prise INTEGER, " +
                "image INTEGER, " +
                "itemCartColor INTEGER, " +
                "isCart INTEGER" +
                ")";
        db.execSQL(CREATE_TABLE_QUERY);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    /** Sepete ekle */
    public boolean addData(String itemName,
                           String itemDisc,
                           int prise,
                           int image,
                           int itemCartColor,
                           int isCart) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("itemName",      itemName);
        cv.put("itemDisc",      itemDisc);
        cv.put("prise",         prise);
        cv.put("image",         image);
        cv.put("itemCartColor", itemCartColor);
        cv.put("isCart",        isCart);
        long id = db.insert(TABLE_NAME, null, cv);
        db.close();
        return id != -1;
    }

    /** Tüm sepet öğelerini çek (id dahil) */
    public ArrayList<ItemClass> getAllDataUser() {
        ArrayList<ItemClass> list = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_NAME, null);

        if (cursor.moveToFirst()) {
            do {
                int    id            = cursor.getInt(0);  // sütun 0 = id
                String itemName      = cursor.getString(1);
                String itemDisc      = cursor.getString(2);
                int    prise         = cursor.getInt(3);
                int    image         = cursor.getInt(4);
                int    itemCartColor = cursor.getInt(5);
                int    isCart        = cursor.getInt(6);

                list.add(new ItemClass(
                        id,
                        itemName,
                        itemDisc,
                        prise,
                        image,
                        itemCartColor,
                        isCart
                ));
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return list;
    }

    /** Sepeti tamamen boşalt */
    public void clear() {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_NAME, null, null);
        db.close();
    }
}
