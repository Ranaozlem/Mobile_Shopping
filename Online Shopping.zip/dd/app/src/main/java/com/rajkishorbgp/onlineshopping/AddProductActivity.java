package com.rajkishorbgp.onlineshopping;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class AddProductActivity extends AppCompatActivity {
    EditText etName, etDesc, etPrice, etDrawable;
    Button btnAdd;
    HomeDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_product);

        etName     = findViewById(R.id.etName);
        etDesc     = findViewById(R.id.etDesc);
        etPrice    = findViewById(R.id.etPrice);
        etDrawable = findViewById(R.id.etDrawableName);
        btnAdd     = findViewById(R.id.btnAdd);
        db         = new HomeDatabase(this);

        btnAdd.setOnClickListener(v -> {
            String name     = etName.getText().toString().trim();
            String desc     = etDesc.getText().toString().trim();
            String priceStr = etPrice.getText().toString().trim();
            String drawable = etDrawable.getText().toString().trim();

            if (name.isEmpty() || desc.isEmpty() || priceStr.isEmpty() || drawable.isEmpty()) {
                Toast.makeText(this, "Tüm alanları doldurun", Toast.LENGTH_SHORT).show();
                return;
            }

            int price = Integer.parseInt(priceStr);
            int resId = getResources()
                    .getIdentifier(drawable, "drawable", getPackageName());
            if (resId == 0) {
                Toast.makeText(this, "Drawable bulunamadı", Toast.LENGTH_SHORT).show();
                return;
            }

            // Varsayılan: sepette değil, kırmızı ikon rengi
            boolean ok = db.addData(name, desc, price, resId,
                    R.color.cart_image_red, 0);
            if (ok) {
                Toast.makeText(this, "Ürün eklendi", Toast.LENGTH_SHORT).show();
                finish(); // ekleme sonrası geri dön
            } else {
                Toast.makeText(this, "Ekleme başarısız", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
