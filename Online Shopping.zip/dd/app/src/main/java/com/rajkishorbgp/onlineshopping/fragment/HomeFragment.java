package com.rajkishorbgp.onlineshopping.fragment;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;

import com.rajkishorbgp.onlineshopping.HomeAdapter;
import com.rajkishorbgp.onlineshopping.HomeDatabase;
import com.rajkishorbgp.onlineshopping.ItemClass;
import com.rajkishorbgp.onlineshopping.MainActivity;
import com.rajkishorbgp.onlineshopping.R;

import java.util.ArrayList;

public class HomeFragment extends Fragment {
    View view;
    ArrayList<ItemClass> homeArrayList;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_home, container, false);
        ListView listView = view.findViewById(R.id.listView);

        // --- 3a) Admin flag’ini alıyoruz ---
        boolean isAdmin = false;
        Bundle args = getArguments();
        if (args != null) {
            isAdmin = args.getBoolean("isAdmin", false);
        }

        HomeDatabase homeDatabase = new HomeDatabase(requireActivity().getApplicationContext());
        homeArrayList = homeDatabase.getAllDataUser();

        // --- Adapter’a isAdmin parametresini geçiyoruz ---
        HomeAdapter homeAdapter = new HomeAdapter(
                requireActivity().getApplicationContext(),
                homeArrayList,
                isAdmin
        );
        listView.setAdapter(homeAdapter);

        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        MainActivity activity = (MainActivity) requireActivity();
        TextView toolbarText = activity.findViewById(R.id.toolbarText);
        toolbarText.setText("Home");
    }
}
