package com.rajkishorbgp.onlineshopping;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.TextView;

import com.google.android.material.navigation.NavigationView;
import com.rajkishorbgp.onlineshopping.fragment.AccountInformationFragment;
import com.rajkishorbgp.onlineshopping.fragment.CartFragment;
import com.rajkishorbgp.onlineshopping.fragment.HomeFragment;
import com.rajkishorbgp.onlineshopping.myclass.LoadData;  // ← eklenen import

public class MainActivity extends AppCompatActivity {
    private Toolbar toolbar;
    private TextView toolbarText;
    private DrawerLayout drawerLayout;
    private NavigationView navigationView;
    private ActionBarDrawerToggle toggle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // --- 1) Eğer veritabanı boşsa, seed verilerini yükle ---
        HomeDatabase seedCheckDb = new HomeDatabase(this);
        if (seedCheckDb.getAllDataUser().isEmpty()) {
            new LoadData(this);
        }
        // -----------------------------------------------

        // View’leri bağla
        toolbar       = findViewById(R.id.toolbar);
        toolbarText   = findViewById(R.id.toolbarText);
        drawerLayout  = findViewById(R.id.drawerLayout);
        navigationView= findViewById(R.id.navigationView);

        // Status bar rengini ayarla
        getWindow().setStatusBarColor(
                ContextCompat.getColor(this, R.color.black)
        );

        // Navigation header bilgileri
        SharedPreferences prefs = getSharedPreferences("userDetails", MODE_PRIVATE);
        View header = navigationView.getHeaderView(0);
        ((TextView) header.findViewById(R.id.profileName))
                .setText(prefs.getString("name",""));
        ((TextView) header.findViewById(R.id.profileEmail))
                .setText(prefs.getString("email",""));

        // --- 2) Menü öğesini admine göre göster ---
        boolean isAdmin = prefs.getBoolean("isAdmin", false);
        Menu navMenu = navigationView.getMenu();
        navMenu.findItem(R.id.addProductMenu)  // bu id’yi drawer_menu.xml içinde eklemeyi unutmayın
                .setVisible(isAdmin);
        // -----------------------------------------

        // Drawer toggle
        toggle = new ActionBarDrawerToggle(
                this, drawerLayout, toolbar,
                R.string.open, R.string.close
        );
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        // Başlangıçta HomeFragment
        getSupportFragmentManager()
                .beginTransaction()
                .add(R.id.fragment, new HomeFragment())
                .commit();
        toolbarText.setText("Home");

        // Menu tıklama dinleyicisi
        navigationView.setNavigationItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.homeMenu) {
                swapFragment(new HomeFragment(), "Home");
            } else if (id == R.id.accountInformation) {
                swapFragment(new AccountInformationFragment(), "Account Information");
            } else if (id == R.id.cartMenu) {
                swapFragment(new CartFragment(), "Cart");
            } else if (id == R.id.addProductMenu) {
                // --- 3) Admin “Ürün Ekle” seçeneğine tıklandığında
                startActivity(new Intent(this, AddProductActivity.class));
            } else if (id == R.id.signOutMenu) {
                signOut();
            }
            drawerLayout.closeDrawer(GravityCompat.START);
            return true;
        });
    }

    /** Fragment geçişini, başlık güncellemeyi ve admin argümanını tek metodda topladık */
    private void swapFragment(Fragment frag, String title) {
        Bundle args = new Bundle();
        boolean isAdmin = getSharedPreferences("userDetails", MODE_PRIVATE)
                .getBoolean("isAdmin", false);
        args.putBoolean("isAdmin", isAdmin);
        frag.setArguments(args);

        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.fragment, frag)
                .commit();
        toolbarText.setText(title);
        drawerLayout.closeDrawer(GravityCompat.START);
    }

    /** Çıkış yap ve LoginActivity’e dön */
    private void signOut() {
        SharedPreferences prefs = getSharedPreferences("userDetails", MODE_PRIVATE);
        prefs.edit().putBoolean("isLogin", false).apply();
        startActivity(new Intent(this, LoginActivity.class));
        finish();
    }
}
