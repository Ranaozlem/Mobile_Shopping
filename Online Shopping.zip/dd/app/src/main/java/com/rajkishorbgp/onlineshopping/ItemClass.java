package com.rajkishorbgp.onlineshopping;

public class ItemClass {
    public int id;
    public String itemName;
    public String itemDisc;
    public int prise;
    public int image;
    public int itemCartColor;
    public int isCart;

    // Yeni: id’li constructor
    public ItemClass(int id,
                     String itemName,
                     String itemDisc,
                     int prise,
                     int image,
                     int itemCartColor,
                     int isCart) {
        this.id            = id;
        this.itemName      = itemName;
        this.itemDisc      = itemDisc;
        this.prise         = prise;
        this.image         = image;
        this.itemCartColor = itemCartColor;
        this.isCart        = isCart;
    }

    public int getId() {
        return id;
    }

    public void setCartColor(int itemCartColor){
        this.itemCartColor = itemCartColor;
    }
}
