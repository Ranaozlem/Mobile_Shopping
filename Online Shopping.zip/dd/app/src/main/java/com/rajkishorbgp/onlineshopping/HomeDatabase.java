package com.rajkishorbgp.onlineshopping;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import androidx.annotation.Nullable;

import java.util.ArrayList;

public class HomeDatabase extends SQLiteOpenHelper {
    private static final String DB_NAME    = "homeDatabase";
    private static final int    DB_VERSION = 1;
    private static final String TABLE_NAME = "homeDatabase";

    private Context context;

    public HomeDatabase(@Nullable Context context) {
        super(context, DB_NAME, null, DB_VERSION);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_TABLE_QUERY = "CREATE TABLE " + TABLE_NAME + "(" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "itemName TEXT, " +
                "itemDisc TEXT, " +
                "prise INTEGER, " +
                "image INTEGER, " +
                "itemCartColor INTEGER, " +
                "isCart INTEGER" +
                ")";
        db.execSQL(CREATE_TABLE_QUERY);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    public boolean addData(String itemName,
                           String itemDisc,
                           int prise,
                           int image,
                           int itemCartColor,
                           int isCart) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("itemName",      itemName);
        cv.put("itemDisc",      itemDisc);
        cv.put("prise",         prise);
        cv.put("image",         image);
        cv.put("itemCartColor", itemCartColor);
        cv.put("isCart",        isCart);
        long id = db.insert(TABLE_NAME, null, cv);
        db.close();
        return id != -1;
    }

    public ArrayList<ItemClass> getAllDataUser() {
        ArrayList<ItemClass> list = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_NAME, null);
        if (cursor.moveToFirst()) {
            do {
                int    id            = cursor.getInt(0);
                String itemName      = cursor.getString(1);
                String itemDisc      = cursor.getString(2);
                int    prise         = cursor.getInt(3);
                int    image         = cursor.getInt(4);
                int    itemCartColor = cursor.getInt(5);
                int    isCart        = cursor.getInt(6);

                list.add(new ItemClass(
                        id,
                        itemName,
                        itemDisc,
                        prise,
                        image,
                        itemCartColor,
                        isCart
                ));
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return list;
    }

    public boolean deleteData(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        int rows = db.delete(
                TABLE_NAME,
                "id = ?",
                new String[]{ String.valueOf(id) }
        );
        db.close();
        return rows > 0;
    }

    public boolean updateIsCart(String itemName,
                                int isCart,
                                int itemCartColor) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("isCart",        isCart);
        cv.put("itemCartColor", itemCartColor);
        int rows = db.update(
                TABLE_NAME,
                cv,
                "itemName = ?",
                new String[]{ itemName }
        );
        db.close();
        return rows > 0;
    }
}
