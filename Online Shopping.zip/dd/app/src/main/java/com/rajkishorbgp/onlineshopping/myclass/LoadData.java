package com.rajkishorbgp.onlineshopping.myclass;

import android.content.Context;

import com.rajkishorbgp.onlineshopping.HomeDatabase;
import com.rajkishorbgp.onlineshopping.ItemClass;
import com.rajkishorbgp.onlineshopping.R;

import java.util.ArrayList;

public class LoadData {

    public LoadData(Context context){
        ArrayList<ItemClass> homeArrayList = new ArrayList<>();

        int itemCartColor = R.color.cart_image_red;

        // 1) Converse
        homeArrayList.add(new ItemClass(
                0,  // ← dummy id
                "Puma X-cell Nova",
                "Erkek | Beyaz | 44 Numara",
                3900,
                R.drawable.puma5,
                itemCartColor,
                0
        ));

        // 2) Nike Air Max
        homeArrayList.add(new ItemClass(
                0,
                "Converse chuck Taylor All Star",
                "Kız Çocuk | Beyaz-Pembe | 34 Numara",
                4900,
                R.drawable.converse5,
                itemCartColor,
                0
        ));




        // 3) Nike Jordan
        homeArrayList.add(new ItemClass(
                0,
                "Lumberjack SATU5FX",
                "Erkek | Beyaz | 43 Numara",
                2059,
                R.drawable.lumberjack5,
                itemCartColor,
                0
        ));

        // 4) Adidas UltraBoost
        homeArrayList.add(new ItemClass(
                0,
                "Nike INITIATOR",
                "Unisex | Beyaz | 40 Numara",
                3399,
                R.drawable.nike5,
                itemCartColor,
                0
        ));

        // 5) Adidas Samba
        homeArrayList.add(new ItemClass(
                0,
                "Lumberjack Frazer S 5FX",
                "Kadın | Beyaz-Siyah | 38 Numara",
                2500,
                R.drawable.lumberjack6,
                itemCartColor,
                0
        ));

        // 6) Puma Runner
        homeArrayList.add(new ItemClass(
                0,
                "Dockers Çocuk Sandalet",
                "Erkek Çocuk | Gri | 33 Numara",
                1290,
                R.drawable.sandaleterkek,
                itemCartColor,
                0
        ));

        homeArrayList.add(new ItemClass(
                0,
                "Vicco Çocuk Sandalet",
                "Kız Çocuk | Pembe | 30 Numara",
                950,
                R.drawable.sandaletkiz,
                itemCartColor,
                0
        ));




        // 5) Adidas Samba
        homeArrayList.add(new ItemClass(
                0,
                "Adidas Samba",
                "Unisex | Siyah | 40 Numara",
                7499,
                R.drawable.adidas2,
                itemCartColor,
                0
        ));

        // 6) Puma Runner
        homeArrayList.add(new ItemClass(
                0,
                "Puma Runner",
                "Çocuk | Mavi | 30 Numara",
                4500,
                R.drawable.puma1,
                itemCartColor,
                0
        ));

        // 7) Puma Future Rider
        homeArrayList.add(new ItemClass(
                0,
                "Puma Future Rider",
                "Erkek | Gri/Mavi | 43 Numara",
                6599,
                R.drawable.puma2,
                itemCartColor,
                0
        ));

        // 8) Reebok Classic
        homeArrayList.add(new ItemClass(
                0,
                "Reebok Classic",
                "Kadın | Pembe | 37 Numara",
                5799,
                R.drawable.reebook1,
                itemCartColor,
                0
        ));

        // 9) New Balance 574
        homeArrayList.add(new ItemClass(
                0,
                "New Balance 574",
                "Unisex | Yeşil | 41 Numara",
                8899,
                R.drawable.newbalance1,
                itemCartColor,
                0
        ));

        // 10) Vans Old Skool
        homeArrayList.add(new ItemClass(
                0,
                "Vans Old Skool",
                "Unisex | Siyah/Beyaz | 39 Numara",
                5599,
                R.drawable.vans1,
                itemCartColor,
                0
        ));

        // Veritabanına ekle
        HomeDatabase homeDatabase = new HomeDatabase(context);
        for (ItemClass item : homeArrayList) {
            homeDatabase.addData(
                    item.itemName,
                    item.itemDisc,
                    item.prise,
                    item.image,
                    item.itemCartColor,
                    item.isCart
            );
        }
    }
}
