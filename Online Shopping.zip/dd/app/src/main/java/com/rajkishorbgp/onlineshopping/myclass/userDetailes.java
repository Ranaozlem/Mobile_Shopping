package com.rajkishorbgp.onlineshopping.myclass;

public class userDetailes {
    public String name;
    public String email;
    public String mobile;
    public String address;
    public String birthday;

    public userDetailes(String name, String email, String mobile, String address, String birthday){
        this.name = name;
        this.email = email;
        this.mobile = mobile;
        this.address = address;
        this.birthday = birthday;
    }
}
