package com.rajkishorbgp.onlineshopping;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.ContextCompat;

import java.util.ArrayList;

public class HomeAdapter extends BaseAdapter {
    private final Context context;
    private final ArrayList<ItemClass> items;
    private final HomeDatabase homeDatabase;
    private final CartDatabase cartDatabase;
    private final boolean isAdmin;

    /**
     * @param context       Kullanıcı arayüzü bağlamı
     * @param items         Gösterilecek ürün listesi
     * @param isAdmin       Admin yetkisi var mı?
     */
    public HomeAdapter(Context context,
                       ArrayList<ItemClass> items,
                       boolean isAdmin) {
        this.context      = context;
        this.items        = items;
        this.isAdmin      = isAdmin;
        this.homeDatabase = new HomeDatabase(context);
        this.cartDatabase = new CartDatabase(context);
    }

    @Override
    public int getCount() {
        return items.size();
    }

    @Override
    public Object getItem(int position) {
        return items.get(position);
    }

    @Override
    public long getItemId(int position) {
        // Eğer gerekirse gerçek ID'yi dönebiliriz: return items.get(position).getId();
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        // ViewHolder pattern kullanabilirsiniz, basitleştirilmiş hali:
        if (convertView == null) {
            convertView = LayoutInflater.from(context)
                    .inflate(R.layout.home_list_view, parent, false);
        }

        ItemClass item = items.get(position);

        ImageView   ivImage     = convertView.findViewById(R.id.itemImage);
        TextView    tvName      = convertView.findViewById(R.id.itemName);
        TextView    tvDesc      = convertView.findViewById(R.id.itemDec);
        TextView    tvPrice     = convertView.findViewById(R.id.itemPrise);
        ImageView   ivCart      = convertView.findViewById(R.id.cartImage);
        ImageButton btnDelete   = convertView.findViewById(R.id.btnDelete);

        // Verileri ata
        ivImage.setImageResource(item.image);
        tvName.setText(item.itemName);
        tvDesc.setText(item.itemDisc);
        tvPrice.setText(item.prise + " TL");
        ivCart.setColorFilter(
                ContextCompat.getColor(context, item.itemCartColor)
        );

        // Sil butonunu sadece admin gösterir
        btnDelete.setVisibility(isAdmin ? View.VISIBLE : View.GONE);

        // Silme işlemi
        btnDelete.setOnClickListener(v -> {
            int targetId = item.getId();
            boolean deleted = homeDatabase.deleteData(targetId);
            if (deleted) {
                items.remove(position);
                notifyDataSetChanged();
                Toast.makeText(context, "Ürün silindi", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(context, "Silme başarısız", Toast.LENGTH_SHORT).show();
            }
        });

        // Sepete ekleme işlemi
        ivCart.setOnClickListener(v -> {
            if (item.isCart == 0) {
                item.isCart = 1;
                boolean ok = cartDatabase.addData(
                        item.itemName,
                        item.itemDisc,
                        item.prise,
                        item.image,
                        item.itemCartColor,
                        item.isCart
                );
                if (ok) {
                    // Rengi güncelle
                    item.setCartColor(R.color.cart_image_green);
                    homeDatabase.updateIsCart(
                            item.itemName,
                            1,
                            R.color.cart_image_green
                    );
                    ivCart.setColorFilter(
                            ContextCompat.getColor(context, item.itemCartColor)
                    );
                    Toast.makeText(context,
                            "Ürün sepete eklendi",
                            Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(context,
                            "Sepete ekleme başarısız",
                            Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(context,
                        "Zaten sepette",
                        Toast.LENGTH_SHORT).show();
            }
        });

        return convertView;
    }
}
